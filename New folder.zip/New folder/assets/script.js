// assets/script.js
console.log("Lost & Found Uganda app loaded!");

// Example: confirm before deleting
function confirmDelete() {
  return confirm("Are you sure you want to delete this item?");
}
