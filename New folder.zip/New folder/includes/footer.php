    </div> <!-- End of container -->
</main>
<footer>
    <p>&copy; <?= date("Y"); ?> Lost & Found Uganda. All Rights Reserved.</p>
</footer>
</body>
</html>
